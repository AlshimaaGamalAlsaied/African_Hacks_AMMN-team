using UnityEngine;
using VRStandardAssets.Utils;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace VRStandardAssets.Examples
{
    // This script is a simple example of how an interactive item can
    // be used to change things on gameobjects by handling events.
    public class ExampleInteractiveItem : MonoBehaviour
    {
        [SerializeField] private VRInteractiveItem m_InteractiveItem;
        [SerializeField] private Renderer m_Renderer;
        [SerializeField] private Material m_OverMaterial;
        [SerializeField] private Material m_NormalMaterial;
        [SerializeField] private Material m_ClickedMaterial;
        [SerializeField] private GameObject m_Appear;
        [SerializeField] private GameObject m_DisAppear;
        [SerializeField] private GameObject m_canavaAppear;
        [SerializeField] private GameObject m_canavaDis;
        [SerializeField] public Transform m_ButtonLabel;
        [SerializeField] public Transform m_ButtonLabelDis;
        [SerializeField] public Transform m_Label;
        [SerializeField] public Transform m_LabelDis;
        [SerializeField] public Transform m_SliderY;
        [SerializeField] public Transform m_SliderX;
       // [SerializeField] public Transform m_SliderMove;
        [SerializeField] public Transform m_SliderScale;
        [SerializeField] public Transform m_labelY;
        [SerializeField] public Transform m_labelX;
      //  [SerializeField] public Transform m_Move;
        [SerializeField] public Transform m_Scale;
      //  [SerializeField] public Transform m_DropDown;
        [SerializeField] public Slider m_MySlider;
        [SerializeField] public Scrollbar m_ScrollLung;
        [SerializeField] public Scrollbar m_Scrollheart;
        [SerializeField] public Scrollbar m_Scroll;
//   [SerializeField] public Text m_text;
        public bool show;
        
        private void Awake()
        {
            m_Scroll = GetComponent<Scrollbar>();
            try
            {
                m_Scroll.enabled = false;
            }
            catch
            {
                Debug.Log("Horrible things happened!");
            }
            // m_NormalMaterial = m_Renderer.material;
            m_MySlider = GetComponent<Slider>();
            
        }


        private void OnEnable()
        {
            Debug.Log("Enable");
            m_InteractiveItem.OnOver += HandleOver;
            m_InteractiveItem.OnOut += HandleOut;
            m_InteractiveItem.OnClick += HandleClick;
        }

        private void OnDisable()
        {
            Debug.Log("Disable");
            m_InteractiveItem.OnOver -= HandleOver;
            m_InteractiveItem.OnOut -= HandleOut;
            m_InteractiveItem.OnClick -= HandleClick;
        }

        //Handle the Over event
        private void HandleOver()
        {
            
            m_Renderer.material = m_OverMaterial;
            Debug.Log("Show over state");
        }

        //Handle the Out event
        private void HandleOut()
        {
            try
            {
                m_Scroll.interactable = false;
            }
            catch
            {
                Debug.Log("Horrible things happened!");
            }
            
            try
            {
                m_MySlider.enabled = false;
            }
            catch 
            {
                Debug.Log("Horrible things happened!");
            }
            m_Renderer.material = m_NormalMaterial;
            Debug.Log("Show out state");
            
        }

        //Handle the Click event
        private void HandleClick()
        {

            if (show)
            {
                show = false;

                try
                {
                    // m_MySlider = GetComponent<UnityEngine.UI.Slider>();
                    m_MySlider.GetComponent<Slider>().enabled = true;
                }
                catch
                {
                    Debug.Log("Horrible things happened!");
                }
                try
                {
                    m_Appear.SetActive(true);
                    m_DisAppear.SetActive(false);
                    m_canavaAppear.SetActive(true);
                    m_canavaDis.SetActive(false);
                    m_ButtonLabel.gameObject.SetActive(true);
                    m_ButtonLabelDis.gameObject.SetActive(false);
                    m_LabelDis.gameObject.SetActive(false);

                }
                catch
                {
                    Debug.Log("Horrible things happened!");
                }
                try
                {
                    m_Scroll.interactable = true;
                }
                catch
                {
                    Debug.Log("Horrible things happened!");
                }
                
                try
                {
                    m_Label.gameObject.SetActive(false);
                }
                catch
                {
                    Debug.Log("Horrible things happened!");
                }

                try
                {
                  //  m_ButtonLabel.gameObject.SetActive(true);
               //     m_DropDown.gameObject.SetActive(true);
                    m_SliderY.gameObject.SetActive(true);
                    m_SliderX.gameObject.SetActive(true);
                //   m_SliderMove.gameObject.SetActive(true);
                    m_SliderScale.gameObject.SetActive(true);
                    m_labelY.gameObject.SetActive(true);
                    m_labelX.gameObject.SetActive(true);
                  //  m_Move.gameObject.SetActive(true);
                    m_Scale.gameObject.SetActive(true);
                }
                catch
                {
                    Debug.Log("Horrible things happened!");
                }
                
                
            }
            else
            {   
                show = true;
                try
                {
                    m_Appear.SetActive(true);
                    m_DisAppear.SetActive(false);
                    m_canavaAppear.SetActive(true);
                    m_canavaDis.SetActive(false);
                    m_ButtonLabel.gameObject.SetActive(true);
                    m_ButtonLabelDis.gameObject.SetActive(false);
                    m_LabelDis.gameObject.SetActive(false);
                }
                catch
                {
                    Debug.Log("Horrible things happened!");
                }
                try
                {
                    m_Scroll.interactable = true;
                }
                catch
                {
                    Debug.Log("Horrible things happened!");
                }
                try
                {
                    m_MySlider = GetComponent<Slider>();
                    m_MySlider.enabled = true;
                }
                catch
                {
                    Debug.Log("Horrible things happened!");
                }
                try
                {
                    m_ScrollLung.interactable = true;
                }
                catch
                {
                    Debug.Log("Horrible things happened!");
                }
                try
                {
                    m_Label.gameObject.SetActive(true);
                }
                catch
                {
                    Debug.Log("Horrible things happened!");
                }
                try
                {
                    
                 //   m_DropDown.gameObject.SetActive(false);
                    m_SliderY.gameObject.SetActive(false);
                    m_SliderX.gameObject.SetActive(false);
                  // m_SliderMove.gameObject.SetActive(false);
                    m_SliderScale.gameObject.SetActive(false);
                    m_labelY.gameObject.SetActive(false);
                    m_labelX.gameObject.SetActive(false);
                 //   m_Move.gameObject.SetActive(false);
                    m_Scale.gameObject.SetActive(false);
                }
                catch
                {
                    Debug.Log("Horrible things happened!");
                }
            }
        
            m_Renderer.material = m_ClickedMaterial;
            Debug.Log("Show click state");
        }
        
    }
}