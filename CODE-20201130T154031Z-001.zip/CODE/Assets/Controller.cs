﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Controller : MonoBehaviour
{

    public GameObject PanelInfo;
    //  public Animation Tiger;
    // public string walkanim;
    // public string AttackAnim;

    public bool show = true;

    public void ShowHideInfo()
    {
        if (!show)
        {
            PanelInfo.SetActive(true);
            show = false;
        }
        else
        {
            PanelInfo.SetActive(false);
            show = true;
        }
    }

  //  public void PlayWalkAnim()
    //{
     //   Tiger.Play(walkanim);
  //  }

    //public void PlayAttackAnim()
    //{
      //  Tiger.Play(AttackAnim);
    //}
}