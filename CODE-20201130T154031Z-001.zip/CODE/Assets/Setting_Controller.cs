﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Setting_Controller : MonoBehaviour
{
    public Transform button_label;
    public bool show;


    // Update is called once per frame
    public void ShowHidenUI()
    {   if (show)
        {
            button_label.gameObject.SetActive(true);
            show = false;
        }
        else
        {
            button_label.gameObject.SetActive(false);
            show = true;

        }
    }
}
